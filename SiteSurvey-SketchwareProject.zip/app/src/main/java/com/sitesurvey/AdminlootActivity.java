package com.sitesurvey;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;


public class AdminlootActivity extends Activity {

	private Button btnback;
	private Button btnclearloot;
	private EditText txtloot;



	private SharedPreferences loot;
	private Intent admin = new Intent();


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adminloot);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		btnback = (Button) findViewById(R.id.btnback);
		btnclearloot = (Button) findViewById(R.id.btnclearloot);
		txtloot = (EditText) findViewById(R.id.txtloot);

		loot = getSharedPreferences("loot", Activity.MODE_PRIVATE);


		btnback.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				admin.setClass(getApplicationContext(), AdminActivity.class);
				startActivity(admin);
				finish();
			}
		});
		btnclearloot.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				loot.edit().remove("1").commit();
				txtloot.setText(loot.getString("1", ""));
				showMessage("Loot Cleared");
			}
		});

	}

	private void  initializeLogic() {
		txtloot.setText(loot.getString("1", ""));
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Integer> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Integer> _result = new ArrayList<Integer>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add(_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
