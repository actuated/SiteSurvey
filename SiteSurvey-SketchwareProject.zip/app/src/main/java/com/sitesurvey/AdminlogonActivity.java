package com.sitesurvey;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;


public class AdminlogonActivity extends Activity {

	private Button btncancel;
	private Button btnclear;
	private Button btnsave;
	private TextView lblbanner;
	private EditText txtorg;
	private TextView lblmessage;
	private EditText txtmessage;
	private TextView lbldom;
	private EditText txtdom;



	private SharedPreferences customdom;
	private SharedPreferences orgname;
	private SharedPreferences msg;
	private Intent admin = new Intent();


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adminlogon);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		btncancel = (Button) findViewById(R.id.btncancel);
		btnclear = (Button) findViewById(R.id.btnclear);
		btnsave = (Button) findViewById(R.id.btnsave);
		lblbanner = (TextView) findViewById(R.id.lblbanner);
		txtorg = (EditText) findViewById(R.id.txtorg);
		lblmessage = (TextView) findViewById(R.id.lblmessage);
		txtmessage = (EditText) findViewById(R.id.txtmessage);
		lbldom = (TextView) findViewById(R.id.lbldom);
		txtdom = (EditText) findViewById(R.id.txtdom);

		customdom = getSharedPreferences("customdom", Activity.MODE_PRIVATE);
		orgname = getSharedPreferences("orgname", Activity.MODE_PRIVATE);
		msg = getSharedPreferences("msg", Activity.MODE_PRIVATE);


		btnsave.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (txtorg.getText().toString().length() > 0) {
					orgname.edit().putString("1", txtorg.getText().toString()).commit();
				}
				else {
					orgname.edit().remove("1").commit();
				}
				if (txtdom.getText().toString().length() > 0) {
					customdom.edit().putString("1", txtdom.getText().toString()).commit();
				}
				else {
					customdom.edit().remove("1").commit();
				}
				if (txtmessage.getText().toString().length() > 0) {
					msg.edit().putString("1", txtmessage.getText().toString()).commit();
				}
				else {
					msg.edit().remove("1").commit();
				}
				showMessage("Custom Logon Screen Settings Saved");
				admin.setClass(getApplicationContext(), AdminActivity.class);
				startActivity(admin);
				finish();
			}
		});
		btncancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				admin.setClass(getApplicationContext(), AdminActivity.class);
				startActivity(admin);
				finish();
			}
		});
		btnclear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				customdom.edit().remove("1").commit();
				orgname.edit().remove("1").commit();
				msg.edit().remove("1").commit();
				showMessage("Custom Logon Screen Settings Reset");
				admin.setClass(getApplicationContext(), AdminActivity.class);
				startActivity(admin);
				finish();
			}
		});

	}

	private void  initializeLogic() {
		txtorg.setText(orgname.getString("1", ""));
		txtdom.setText(customdom.getString("1", ""));
		txtmessage.setText(msg.getString("1", ""));
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Integer> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Integer> _result = new ArrayList<Integer>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add(_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
