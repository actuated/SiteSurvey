package com.sitesurvey;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;


public class SettingsActivity extends Activity {

	private Button btncancel;
	private Button btnsavepass;
	private TextView lblpwd;
	private EditText txtpwd;
	private EditText txtconfirmpwd;



	private Intent admin = new Intent();
	private SharedPreferences pref;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		btncancel = (Button) findViewById(R.id.btncancel);
		btnsavepass = (Button) findViewById(R.id.btnsavepass);
		lblpwd = (TextView) findViewById(R.id.lblpwd);
		txtpwd = (EditText) findViewById(R.id.txtpwd);
		txtconfirmpwd = (EditText) findViewById(R.id.txtconfirmpwd);


		pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);

		btncancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				admin.setClass(getApplicationContext(), AdminActivity.class);
				startActivity(admin);
				finish();
			}
		});
		btnsavepass.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (txtpwd.getText().toString().equals(txtconfirmpwd.getText().toString())) {
					pref.edit().putString("1", txtpwd.getText().toString()).commit();
					showMessage("Password Saved");
					admin.setClass(getApplicationContext(), AdminActivity.class);
				}
				else {
					showMessage("New Password Doesn't Match Confirm Password Field");
					admin.setClass(getApplicationContext(), SettingsActivity.class);
				}
				startActivity(admin);
				finish();
			}
		});

	}

	private void  initializeLogic() {
		if (pref.getString("1", "").length() > 0) {
			txtpwd.setText(pref.getString("1", ""));
			txtconfirmpwd.setText(pref.getString("1", ""));
		}
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Integer> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Integer> _result = new ArrayList<Integer>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add(_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
