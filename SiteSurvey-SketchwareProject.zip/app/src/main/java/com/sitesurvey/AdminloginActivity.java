package com.sitesurvey;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;


public class AdminloginActivity extends Activity {

	private Button btnmain;
	private Button btnadminlogin;
	private EditText txtadminpwd;

	private String varSubmitAdmPwd = "";
	private String varAdmPwd = "";


	private Intent adminpage = new Intent();
	private Intent main = new Intent();
	private SharedPreferences pref;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adminlogin);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		btnmain = (Button) findViewById(R.id.btnmain);
		btnadminlogin = (Button) findViewById(R.id.btnadminlogin);
		txtadminpwd = (EditText) findViewById(R.id.txtadminpwd);



		pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);

		btnadminlogin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (txtadminpwd.getText().toString().equals(varAdmPwd)) {
					adminpage.setClass(getApplicationContext(), AdminActivity.class);
					startActivity(adminpage);
				}
				else {
					showMessage("You Didn't Say the Magic Word");
					main.setClass(getApplicationContext(), AdminloginActivity.class);
					startActivity(main);
				}
				finish();
			}
		});
		btnmain.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				main.setClass(getApplicationContext(), MainActivity.class);
				startActivity(main);
				finish();
			}
		});

	}

	private void  initializeLogic() {
		if (pref.getString("1", "").length() > 0) {
			varAdmPwd = pref.getString("1", "");
		}
		else {
			varAdmPwd = "SiteSurvey";
		}
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Integer> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Integer> _result = new ArrayList<Integer>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add(_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
