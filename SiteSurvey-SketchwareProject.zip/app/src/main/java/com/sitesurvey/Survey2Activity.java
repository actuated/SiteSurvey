package com.sitesurvey;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;


public class Survey2Activity extends Activity {

	private TextView lblquestion;
	private ListView lstanswers;


	private ArrayList<String> answers = new ArrayList<String>();

	private Intent change = new Intent();
	private SharedPreferences questions;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.survey2);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		lblquestion = (TextView) findViewById(R.id.lblquestion);
		lstanswers = (ListView) findViewById(R.id.lstanswers);


		questions = getSharedPreferences("questions", Activity.MODE_PRIVATE);

		lstanswers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView _parent, View _view, int _position, long _id) { 
				if (questions.getString("3", "").length() > 0) {
					change.setClass(getApplicationContext(), Survey3Activity.class);
				}
				else {
					change.setClass(getApplicationContext(), SurveydoneActivity.class);
				}
				startActivity(change);
				finish();
			}
		});

	}

	private void  initializeLogic() {
		lblquestion.setText(questions.getString("2", ""));
		answers.add("Yes");
		answers.add("Neutral");
		answers.add("No");
		lstanswers.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, answers));
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Integer> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Integer> _result = new ArrayList<Integer>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add(_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
