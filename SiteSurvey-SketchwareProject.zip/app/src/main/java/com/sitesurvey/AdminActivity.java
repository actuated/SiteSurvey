package com.sitesurvey;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;


public class AdminActivity extends Activity {

	private Button btnmain;
	private Button btnloot;
	private Button btnadminpwd;
	private Button btnloginsettings;
	private Button btnsurveyqs;
	private TextView lblcredits;
	private TextView lblversion;


	private ArrayList<String> strLoot = new ArrayList<String>();

	private Intent main = new Intent();
	private Intent settings = new Intent();
	private Intent lootscreen = new Intent();
	private Intent logonsettings = new Intent();
	private Intent surveyq = new Intent();


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.admin);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		btnmain = (Button) findViewById(R.id.btnmain);
		btnloot = (Button) findViewById(R.id.btnloot);
		btnadminpwd = (Button) findViewById(R.id.btnadminpwd);
		btnloginsettings = (Button) findViewById(R.id.btnloginsettings);
		btnsurveyqs = (Button) findViewById(R.id.btnsurveyqs);
		lblcredits = (TextView) findViewById(R.id.lblcredits);
		lblversion = (TextView) findViewById(R.id.lblversion);







		btnmain.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				main.setClass(getApplicationContext(), MainActivity.class);
				startActivity(main);
				finish();
			}
		});
		btnadminpwd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				settings.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(settings);
				finish();
			}
		});
		btnloot.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				lootscreen.setClass(getApplicationContext(), AdminlootActivity.class);
				startActivity(lootscreen);
				finish();
			}
		});
		btnloginsettings.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				logonsettings.setClass(getApplicationContext(), AdminlogonActivity.class);
				startActivity(logonsettings);
				finish();
			}
		});
		btnsurveyqs.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				surveyq.setClass(getApplicationContext(), AdminsurveyqsActivity.class);
				startActivity(surveyq);
				finish();
			}
		});

	}

	private void  initializeLogic() {

	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Integer> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Integer> _result = new ArrayList<Integer>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add(_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
