package com.sitesurvey;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;


public class AdminsurveyqsActivity extends Activity {

	private Button btnback;
	private Button btnclear;
	private Button btnsave;
	private EditText txtq1;
	private EditText txtq2;
	private EditText txtq3;



	private Intent admin = new Intent();
	private SharedPreferences questions;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adminsurveyqs);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		btnback = (Button) findViewById(R.id.btnback);
		btnclear = (Button) findViewById(R.id.btnclear);
		btnsave = (Button) findViewById(R.id.btnsave);
		txtq1 = (EditText) findViewById(R.id.txtq1);
		txtq2 = (EditText) findViewById(R.id.txtq2);
		txtq3 = (EditText) findViewById(R.id.txtq3);


		questions = getSharedPreferences("questions", Activity.MODE_PRIVATE);

		btnback.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				admin.setClass(getApplicationContext(), AdminActivity.class);
				startActivity(admin);
				finish();
			}
		});
		btnsave.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (txtq1.getText().toString().length() > 0) {
					questions.edit().putString("1", txtq1.getText().toString()).commit();
				}
				else {
					questions.edit().remove("1").commit();
				}
				if (txtq2.getText().toString().length() > 0) {
					questions.edit().putString("2", txtq2.getText().toString()).commit();
				}
				else {
					questions.edit().remove("2").commit();
				}
				if (txtq3.getText().toString().length() > 0) {
					questions.edit().putString("3", txtq3.getText().toString()).commit();
				}
				else {
					questions.edit().remove("3").commit();
				}
				showMessage("Questions Saved");
				admin.setClass(getApplicationContext(), AdminActivity.class);
				startActivity(admin);
				finish();
			}
		});
		btnclear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				questions.edit().remove("1").commit();
				questions.edit().remove("2").commit();
				questions.edit().remove("3").commit();
				showMessage("Survey Questions Cleared");
				admin.setClass(getApplicationContext(), AdminActivity.class);
				startActivity(admin);
				finish();
			}
		});

	}

	private void  initializeLogic() {
		if (questions.getString("1", "").length() > 0) {
			txtq1.setText(questions.getString("1", ""));
		}
		if (questions.getString("2", "").length() > 0) {
			txtq2.setText(questions.getString("2", ""));
		}
		if (questions.getString("3", "").length() > 0) {
			txtq3.setText(questions.getString("3", ""));
		}
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Integer> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Integer> _result = new ArrayList<Integer>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add(_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
