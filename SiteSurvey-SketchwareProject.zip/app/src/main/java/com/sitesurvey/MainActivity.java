package com.sitesurvey;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import java.util.*;
import java.text.*;


public class MainActivity extends Activity {

	private ImageView imgbanner;
	private TextView txtorg;
	private TextView lblmsg;
	private EditText txtdomain;
	private EditText txtuser;
	private EditText txtpass;
	private Button btnlogin;
	private Button btnreset;
	private ImageView imgadmin;

	private String InCreds = "";


	private Timer _timer = new Timer();
	private Intent adminlogin = new Intent();
	private TimerTask fakeauth;
	private Intent survey = new Intent();
	private SharedPreferences loot;
	private SharedPreferences customdom;
	private SharedPreferences orgname;
	private SharedPreferences msg;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		imgbanner = (ImageView) findViewById(R.id.imgbanner);
		txtorg = (TextView) findViewById(R.id.txtorg);
		lblmsg = (TextView) findViewById(R.id.lblmsg);
		txtdomain = (EditText) findViewById(R.id.txtdomain);
		txtuser = (EditText) findViewById(R.id.txtuser);
		txtpass = (EditText) findViewById(R.id.txtpass);
		btnlogin = (Button) findViewById(R.id.btnlogin);
		btnreset = (Button) findViewById(R.id.btnreset);
		imgadmin = (ImageView) findViewById(R.id.imgadmin);




		loot = getSharedPreferences("loot", Activity.MODE_PRIVATE);
		customdom = getSharedPreferences("customdom", Activity.MODE_PRIVATE);
		orgname = getSharedPreferences("orgname", Activity.MODE_PRIVATE);
		msg = getSharedPreferences("msg", Activity.MODE_PRIVATE);

		btnlogin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				InCreds = loot.getString("1", "");
				InCreds = InCreds.concat(txtuser.getText().toString());
				InCreds = InCreds.concat(":");
				InCreds = InCreds.concat(txtpass.getText().toString());
				InCreds = InCreds.concat(" ");
				loot.edit().putString("1", InCreds).commit();
				showMessage("Authenticating...");
				fakeauth = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														showMessage("Success!");
										}
									});
								}
							};
							_timer.schedule(fakeauth, (int)(500));
				fakeauth = new TimerTask() {
							@Override
								public void run() {
									runOnUiThread(new Runnable() {
									@Override
										public void run() {
														survey.setClass(getApplicationContext(), SurveyActivity.class);
										startActivity(survey);
										txtuser.setText("");
										txtpass.setText("");
										finish();
										}
									});
								}
							};
							_timer.schedule(fakeauth, (int)(3000));
			}
		});
		imgadmin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				adminlogin.setClass(getApplicationContext(), AdminloginActivity.class);
				startActivity(adminlogin);
				finish();
			}
		});
		btnreset.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				txtuser.setText("");
				txtpass.setText("");
			}
		});

	}

	private void  initializeLogic() {
		if (customdom.getString("1", "").length() > 0) {
			txtdomain.setText(customdom.getString("1", ""));
			txtdomain.setVisibility(View.VISIBLE);
		}
		else {
			txtdomain.setText("domain\\");
			txtdomain.setVisibility(View.GONE);
		}
		if (orgname.getString("1", "").length() > 0) {
			txtorg.setText(orgname.getString("1", ""));
			txtorg.setVisibility(View.VISIBLE);
		}
		else {
			txtorg.setText("SiteSurvey");
			txtorg.setVisibility(View.GONE);
		}
		if (msg.getString("1", "").length() > 0) {
			lblmsg.setText(msg.getString("1", ""));
		}
		else {
			lblmsg.setText("Please log in to take a quick survey rating today's service experience. This app uses your Windows domain username and password.");
		}
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Integer> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Integer> _result = new ArrayList<Integer>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add(_arr.keyAt(_iIdx));
		}
		return _result;
	}

}
